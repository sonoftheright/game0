# TODO #


## IN DEVELOPMENT ##
 - Platform code
 	- HH style renderer (before later modification)
 	- HH style audio streaming
 	- HH style event handling/input
 - Platform code encapsulation/layer division

## PLANNED ##
## STAGING ##
## IDEABOX ##
## COMPLETED ##