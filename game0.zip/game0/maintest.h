//maintest.h
#define global_variable static
#define local_persist static
#define internal static 				//for internal functions

global_variable bool global_running;
