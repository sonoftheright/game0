# Architectural Brainstorm #

I stupidly began this in a typically OOP way. Now, let's talk about the data. What data do we need, how can it be optimally arranged, and how will it be modified, accessed, and used in game?

## Data ##

Map data
	Referential point/position data (for entity position references)
	Line of sight data?
	Pathfinding division data?
Entity data (Variable data only?)
	Position
	Name
	Behavioral references
Behavior data
	Action modules
		Pathfinding
		Entity database searching/Entity knowledge
Asset data
	Animation data